'use strict';

const images = [
  {title: 'Purrr, purrr', text: 'Refuse to drink water except out of someone\'s glass steal the warm chair right after you get up hopped up on catnip, and licks paws, and make meme, make cute face, meowwww.', url: 'http://placekitten.com/768/432'},
  {title: 'Random', text: 'What, what', url: ''},
  {title: 'Murray', text: 'Uhuh ... yih!', url: ''},
  {title: 'Crazy Cage', text: 'check out this dolizzle shizznit amizzle', url: ''},
  {title: 'Normal Cage', text: 'crazy adipiscing dope', url: ''},
  {title: 'Bear', text: 'Nullizzle sapizzle velit', url: ''},
  {title: 'Bacon', text: 'check it out vizzle', url: 'http://baconmockup.com/640/360'},
];

// http://placeimg.com/640/360
// http://fillmurray.com/640/360
// http://placecage.com/c/640/360
// http://placecage.com/640/360
// http://placebear.com/640/360

var imageOrder = 0;
var thumbnail = document.querySelectorAll('.small');
var largeImage = document.querySelector('.large');
var descriptionTitle = document.querySelector('h3');
var descriptionText = document.querySelector('p');
var leftButton = document.querySelector('.left');
var rightButton = document.querySelector('.right');

for (let i = 0; i < thumbnail.length; i++) {
  thumbnail[i].setAttribute('src', images[i].url);
}

largeImage.style.backgroundImage = 'url(\'' + images[imageOrder].url + '\')';
descriptionTitle.innerHTML = images[imageOrder].title;
descriptionText.innerHTML = images[imageOrder].text;

leftButton.addEventListener('click', function(){
  changePic(-1);
});
rightButton.addEventListener('click', function(){
  changePic(1);
});

function changePic(direction) {
  imageOrder += direction;
  if(imageOrder === images.length) {
    imageOrder = 0;
  } else if(imageOrder < 0) {
    imageOrder = images.length - 1;
  }
  largeImage.style.backgroundImage = 'url(\'' + images[imageOrder].url + '\')';
  descriptionTitle.innerHTML = images[imageOrder].title;
  descriptionText.innerHTML = images[imageOrder].text;
  console.log(imageOrder);
};
